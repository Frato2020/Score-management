#include <stdio.h>
#include <string.h>

int main()
{
//    int a=0;
//    scanf("%d",&a);

//    char pass[]="Hello";
//
//    char input[6];char output[6];
//    do
//    {
//        gets(input);
//        gets(output);
//        if(strcmp(input,pass)==0)
//            printf("Right!");
//        else
//            printf("Wrong!");
//    }while(strcmp(input,pass)!=0);
//    printf("%p\n%p\n%p",pass,input,output);

//    int a,b,c,d;
//    printf("%p\n%p\n%p\n%p",&a,&b,&c,&d);

//    char a[10];
//    scanf("%s",a);
//    printf("%s   %d\n",a,strlen(a));
//    gets(a);
//    printf("%s   %d\n",a,strlen(a));
//    fgets(a,10,stdin);
//    printf("%s   %d\n",a,strlen(a));

    char c[5];
    fgets(c,5,stdin);
    printf("%s\t%d\n",c,strlen(c));
    c[strlen(c)-1]='\0';
    fgets(c,5,stdin);
    printf("%s",c);
    return 0;
}
